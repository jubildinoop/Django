from django.contrib import messages
from django.contrib.auth import authenticate, logout
# from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect

# Create your views here.
from app1.forms import *
from app1.models import *


def index(request):
    return render(request, 'index.html')


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('uname')
        password = request.POST.get('pass')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            Login(request, user)
            if user.is_admin:  # admin
                return redirect('admin_home')
            elif user.is_student:
                return redirect('student_home')
        else:
            messages.info(request, "Invalid Credentials")
    return render(request, 'login.html')


## logout page ##
def logout_view(request):
    logout(request)
    return redirect('login_view')


## admin home ##
def admin_home(request):
    return render(request, 'admin_home.html')


def register(request):
    admin_form = LoginRegister()
    student_form = StudentRegister()
    if request.method == 'POST':
        admin_form = LoginRegister(request.POST)
        student_form = StudentRegister(request.POST)
        if admin_form.is_valid() and student_form.is_valid():
            user = admin_form.save(commit=False)
            user.is_admin = True
            user.save()
            stud = student_form.save(commit=False)
            stud.user = user
            stud.save()
            messages.info(request, "User registered successfully")
            return redirect('login_view')
    return render(request, 'registration.html', {'admin_form': admin_form, 'student_form': student_form})
