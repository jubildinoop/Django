import re

from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError

from app1.models import *

class DateInput(forms.DateInput):
    input_type = 'date'

def phone_number_validator(value):
    if not re.compile(r'^[7-9]\d{9}$').match(value):
        raise ValidationError('This is not a valid phone number')


class LoginRegister(UserCreationForm):
    username = forms.CharField(max_length=50)
    password = forms.CharField(label='Password', widget=forms.PasswordInput)

    class Meta:
        model = Login
        fields = ('username', 'password')


class StudentRegister(forms.ModelForm):
    phone = forms.IntegerField(validators=[phone_number_validator])

    class Meta:
        model = Student
        fields = ('name', 'dob', 'phone', 'password', 'photo')
        widgets = {
            'photo': forms.FileInput(attrs={'class': 'form-control'}),

        }


class AdminRegister(forms.ModelForm):
    phone = forms.IntegerField(validators=[phone_number_validator])

    class Meta:
        model = Admin
        fields = ('name', 'dob', 'phone', 'password', 'photo')
        widgets = {
            'photo': forms.FileInput(attrs={'class': 'form-control'}),

        }

