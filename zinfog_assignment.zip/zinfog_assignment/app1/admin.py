from django.contrib import admin

# Register your models here.
from app1 import models

admin.site.register(models.Login)
admin.site.register(models.Student)
admin.site.register(models.Admin)

