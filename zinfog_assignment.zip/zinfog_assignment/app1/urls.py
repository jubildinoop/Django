from django.urls import path

from app1 import views

urlpatterns = [
    path('index/', views.index, name='index'),
    path('login_view/', views.login_view, name="login_view"),
    path('logout_view/', views.logout_view, name="logout_view"),
    path('admin_home/', views.admin_home, name='admin_home'),
    path('register/', views.register, name='register'),

 ]
