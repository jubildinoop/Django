from django.contrib.auth.models import AbstractUser, User
from django.db import models


# Create your models here.
class Login(AbstractUser):
    is_admin = models.BooleanField(default=False)
    is_student = models.BooleanField(default=False)


class Student(models.Model):
    # user = models.ForeignKey(Login, on_delete=models.CASCADE, related_name='student')
    name = models.CharField(max_length=50)
    dob = models.DateField()
    phone = models.IntegerField(null=True, blank=True)
    password = models.CharField(max_length=50)
    photo = models.ImageField(upload_to='profile')

    def __str__(self):
        return self.name


class Admin(models.Model):
    # user = models.ForeignKey(Login, on_delete=models.CASCADE, related_name='student')
    name = models.CharField(max_length=50)
    dob = models.DateField()
    phone = models.IntegerField(null=True, blank=True)
    password = models.CharField(max_length=50)
    photo = models.ImageField(upload_to='profile')

    def __str__(self):
        return self.name
